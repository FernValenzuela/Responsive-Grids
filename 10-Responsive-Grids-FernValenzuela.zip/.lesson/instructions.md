# Instructions  

---

Use `auto-fill` and `minmax` to make these cards align in a grid.
When there's not enough space, all four cards should have their
own row like this:

![1](./assets/1.png)

When the window expands, there should be two cards on each
row like this:

![2](./assets/2.png)

When the window gets even larger:

![3](./assets/3.png)

Finally, at the largest window
width:

![4](./assets/4.png)